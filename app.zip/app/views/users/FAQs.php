<?php
include APP_DIR.'views/includes/users/header.php';
?>

<style>
    body {
            background-color: #f8f9fa;
        }
        .accordion-button {
            color: black; /* Customize button text color */
        }
        .accordion-button:not(.collapsed) {
            color: white; /* Expanded text color */
        }
        .accordion-item {
            border: none; /* Remove borders for a cleaner look */
            margin-bottom: 10px; /* Space between items */
        }
        h1 {
            margin-bottom: 40px; /* Space below the title */
            font-size: 2.5rem; /* Title font size */
        }
        .accordion-body {
            background-color: #ffffff; /* White background for body */
        }
</style>

<div class="container mt-5">
        <h1 class="text-center">Frequently Asked Questions</h1>
        <div class="accordion" id="faqAccordion">
            <div class="accordion-item">
                <h2 class="accordion-header" id="headingOne">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                        What should I expect during my first visit?
                    </button>
                </h2>
                <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#faqAccordion">
                    <div class="accordion-body">
                        During your first visit, we will conduct a comprehensive examination of your dental health. This may include X-rays, a discussion of your medical history, and a consultation about your oral health goals.
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header" id="headingTwo">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                        How often should I visit the dentist?
                    </button>
                </h2>
                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#faqAccordion">
                    <div class="accordion-body">
                        It is recommended to visit the dentist at least twice a year for routine check-ups and cleanings. However, the frequency may vary based on your individual dental needs.
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header" id="headingThree">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                        What types of dental services do you offer?
                    </button>
                </h2>
                <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#faqAccordion">
                    <div class="accordion-body">
                        We offer a wide range of dental services including general dentistry, cosmetic dentistry, orthodontics, pediatric dentistry, and emergency dental care.
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header" id="headingFour">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                        How can I handle dental emergencies?
                    </button>
                </h2>
                <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#faqAccordion">
                    <div class="accordion-body">
                        If you experience a dental emergency, such as a toothache, broken tooth, or injury to the mouth, contact our office immediately for guidance on the next steps and to schedule an emergency appointment.
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header" id="headingFive">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                        Do you accept insurance?
                    </button>
                </h2>
                <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#faqAccordion">
                    <div class="accordion-body">
                        Yes, we accept a variety of dental insurance plans. Please contact our office for specific information about your plan and any payment options available.
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
include APP_DIR.'views/includes/users/footer.php';
?> 
